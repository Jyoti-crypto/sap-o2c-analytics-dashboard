"""
SAP Order-to-Cash (O2C) Analytics Dashboard
Capstone Project | Jyoti Kumari | Roll No: 2305297 | CSE
"""

import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
import numpy as np
import warnings
warnings.filterwarnings('ignore')

# ── Style ──────────────────────────────────────────────────────
plt.rcParams.update({
    'font.family': 'DejaVu Sans',
    'axes.spines.top': False,
    'axes.spines.right': False,
    'figure.dpi': 150,
})
SAP_BLUE  = '#003366'
SAP_TEAL  = '#007DB8'
SAP_GOLD  = '#F0AB00'
SAP_GREEN = '#2D8653'
SAP_RED   = '#D32F2F'
PALETTE   = [SAP_BLUE, SAP_TEAL, SAP_GOLD, SAP_GREEN, SAP_RED,
             '#6A0DAD', '#FF6600', '#00897B']

# ── Load Data ──────────────────────────────────────────────────
df  = pd.read_csv('/home/claude/sap_project/data/sap_sales_orders.csv')
inv = pd.read_csv('/home/claude/sap_project/data/sap_inventory.csv')

# ── KPI Summary ───────────────────────────────────────────────
total_revenue   = df['Total_Amount'].sum()
total_orders    = len(df)
avg_order_value = df['Total_Amount'].mean()
completion_rate = (df['Status'] == 'Completed').mean() * 100
top_customer    = df.groupby('Customer_Name')['Total_Amount'].sum().idxmax()

print("=" * 55)
print("  SAP O2C ANALYTICS — KEY METRICS")
print("=" * 55)
print(f"  Total Revenue       : ₹{total_revenue:>15,.0f}")
print(f"  Total Orders        : {total_orders:>15}")
print(f"  Avg Order Value     : ₹{avg_order_value:>15,.0f}")
print(f"  Completion Rate     : {completion_rate:>14.1f}%")
print(f"  Top Customer        : {top_customer}")
print("=" * 55)

# ════════════════════════════════════════════════════════
# CHART 1 — Monthly Revenue Trend
# ════════════════════════════════════════════════════════
month_order = ['January','February','March','April','May','June',
               'July','August','September','October','November','December']
monthly = df.groupby('Month')['Total_Amount'].sum().reindex(month_order).dropna()

fig, ax = plt.subplots(figsize=(12, 5))
bars = ax.bar(monthly.index, monthly.values, color=SAP_TEAL, alpha=0.85, width=0.6, zorder=3)
ax.plot(monthly.index, monthly.values, color=SAP_GOLD, marker='o',
        linewidth=2.5, markersize=7, zorder=4)
ax.fill_between(range(len(monthly)), monthly.values, alpha=0.12, color=SAP_TEAL)
for bar, val in zip(bars, monthly.values):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 80000,
            f'₹{val/1e6:.1f}M', ha='center', va='bottom', fontsize=8.5, color=SAP_BLUE, fontweight='bold')
ax.set_title('Monthly Revenue Trend — FY 2024', fontsize=15, fontweight='bold', color=SAP_BLUE, pad=15)
ax.set_xlabel('Month', fontsize=11)
ax.set_ylabel('Revenue (₹)', fontsize=11)
ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f'₹{x/1e6:.1f}M'))
ax.grid(axis='y', linestyle='--', alpha=0.4, zorder=0)
ax.set_xticks(range(len(monthly)))
ax.set_xticklabels([m[:3] for m in monthly.index], fontsize=10)
plt.tight_layout()
plt.savefig('/home/claude/sap_project/charts/chart1_monthly_revenue.png', bbox_inches='tight')
plt.close()
print("✅ Chart 1 saved")

# ════════════════════════════════════════════════════════
# CHART 2 — Top 5 Customers by Revenue
# ════════════════════════════════════════════════════════
top_customers = df.groupby('Customer_Name')['Total_Amount'].sum().nlargest(5).sort_values()
fig, ax = plt.subplots(figsize=(10, 5))
bars = ax.barh(top_customers.index, top_customers.values,
               color=PALETTE[:5], height=0.55, zorder=3)
for bar, val in zip(bars, top_customers.values):
    ax.text(val + 50000, bar.get_y() + bar.get_height()/2,
            f'₹{val/1e6:.2f}M', va='center', fontsize=9.5, fontweight='bold', color=SAP_BLUE)
ax.set_title('Top 5 Customers by Total Revenue', fontsize=15, fontweight='bold', color=SAP_BLUE, pad=15)
ax.set_xlabel('Total Revenue (₹)', fontsize=11)
ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f'₹{x/1e6:.1f}M'))
ax.grid(axis='x', linestyle='--', alpha=0.4, zorder=0)
plt.tight_layout()
plt.savefig('/home/claude/sap_project/charts/chart2_top_customers.png', bbox_inches='tight')
plt.close()
print("✅ Chart 2 saved")

# ════════════════════════════════════════════════════════
# CHART 3 — Order Status Distribution (Pie)
# ════════════════════════════════════════════════════════
status_counts = df['Status'].value_counts()
colors_pie = [SAP_GREEN, SAP_GOLD, SAP_TEAL]
explode = [0.03] * len(status_counts)
fig, ax = plt.subplots(figsize=(7, 6))
wedges, texts, autotexts = ax.pie(
    status_counts.values, labels=status_counts.index,
    autopct='%1.1f%%', colors=colors_pie, explode=explode,
    startangle=140, textprops={'fontsize': 11},
    wedgeprops={'edgecolor': 'white', 'linewidth': 2})
for at in autotexts:
    at.set_fontweight('bold')
ax.set_title('Order Status Distribution', fontsize=15, fontweight='bold', color=SAP_BLUE, pad=20)
plt.tight_layout()
plt.savefig('/home/claude/sap_project/charts/chart3_order_status.png', bbox_inches='tight')
plt.close()
print("✅ Chart 3 saved")

# ════════════════════════════════════════════════════════
# CHART 4 — Regional Revenue Comparison
# ════════════════════════════════════════════════════════
regional = df.groupby('Region')['Total_Amount'].sum().sort_values(ascending=False)
fig, ax = plt.subplots(figsize=(8, 5))
bars = ax.bar(regional.index, regional.values,
              color=[SAP_BLUE, SAP_TEAL, SAP_GOLD, SAP_GREEN], width=0.5, zorder=3)
for bar, val in zip(bars, regional.values):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 100000,
            f'₹{val/1e6:.2f}M', ha='center', fontsize=10, fontweight='bold', color=SAP_BLUE)
ax.set_title('Revenue by Region', fontsize=15, fontweight='bold', color=SAP_BLUE, pad=15)
ax.set_xlabel('Region', fontsize=11)
ax.set_ylabel('Revenue (₹)', fontsize=11)
ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f'₹{x/1e6:.1f}M'))
ax.grid(axis='y', linestyle='--', alpha=0.4, zorder=0)
plt.tight_layout()
plt.savefig('/home/claude/sap_project/charts/chart4_regional_revenue.png', bbox_inches='tight')
plt.close()
print("✅ Chart 4 saved")

# ════════════════════════════════════════════════════════
# CHART 5 — Product Revenue Breakdown
# ════════════════════════════════════════════════════════
prod_rev = df.groupby('Product_Name')['Total_Amount'].sum().sort_values()
fig, ax = plt.subplots(figsize=(11, 5))
colors_prod = plt.cm.Blues(np.linspace(0.4, 0.9, len(prod_rev)))
bars = ax.barh(prod_rev.index, prod_rev.values, color=colors_prod, height=0.6, zorder=3)
for bar, val in zip(bars, prod_rev.values):
    ax.text(val + 50000, bar.get_y() + bar.get_height()/2,
            f'₹{val/1e6:.2f}M', va='center', fontsize=9, fontweight='bold', color=SAP_BLUE)
ax.set_title('Revenue by Product', fontsize=15, fontweight='bold', color=SAP_BLUE, pad=15)
ax.set_xlabel('Total Revenue (₹)', fontsize=11)
ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f'₹{x/1e6:.1f}M'))
ax.grid(axis='x', linestyle='--', alpha=0.4, zorder=0)
plt.tight_layout()
plt.savefig('/home/claude/sap_project/charts/chart5_product_revenue.png', bbox_inches='tight')
plt.close()
print("✅ Chart 5 saved")

# ════════════════════════════════════════════════════════
# CHART 6 — Quarterly Performance
# ════════════════════════════════════════════════════════
quarterly = df.groupby('Quarter').agg(Revenue=('Total_Amount','sum'), Orders=('Order_ID','count')).reset_index()
fig, ax1 = plt.subplots(figsize=(8, 5))
ax2 = ax1.twinx()
bars = ax1.bar(quarterly['Quarter'], quarterly['Revenue'], color=SAP_TEAL, alpha=0.75, width=0.4, zorder=3, label='Revenue')
ax2.plot(quarterly['Quarter'], quarterly['Orders'], color=SAP_GOLD, marker='D',
         linewidth=2.5, markersize=9, zorder=4, label='Orders')
for bar, val in zip(bars, quarterly['Revenue']):
    ax1.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 100000,
             f'₹{val/1e6:.1f}M', ha='center', fontsize=9, fontweight='bold', color=SAP_BLUE)
ax1.set_title('Quarterly Revenue vs Order Volume', fontsize=15, fontweight='bold', color=SAP_BLUE, pad=15)
ax1.set_xlabel('Quarter', fontsize=11)
ax1.set_ylabel('Revenue (₹)', fontsize=11, color=SAP_TEAL)
ax2.set_ylabel('Number of Orders', fontsize=11, color=SAP_GOLD)
ax1.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f'₹{x/1e6:.1f}M'))
ax1.grid(axis='y', linestyle='--', alpha=0.3, zorder=0)
lines1, labels1 = ax1.get_legend_handles_labels()
lines2, labels2 = ax2.get_legend_handles_labels()
ax1.legend(lines1 + lines2, labels1 + labels2, loc='upper left', fontsize=10)
plt.tight_layout()
plt.savefig('/home/claude/sap_project/charts/chart6_quarterly.png', bbox_inches='tight')
plt.close()
print("✅ Chart 6 saved")

# ════════════════════════════════════════════════════════
# DASHBOARD — Combined KPI Overview
# ════════════════════════════════════════════════════════
fig = plt.figure(figsize=(16, 10))
fig.patch.set_facecolor('#F5F7FA')

# Header
ax_header = fig.add_axes([0, 0.92, 1, 0.08])
ax_header.set_facecolor(SAP_BLUE)
ax_header.text(0.5, 0.55, 'SAP Order-to-Cash (O2C) Analytics Dashboard',
               ha='center', va='center', fontsize=18, fontweight='bold', color='white', transform=ax_header.transAxes)
ax_header.text(0.5, 0.15, 'Capstone Project | Jyoti Kumari | Roll No: 2305297 | CSE | FY 2024',
               ha='center', va='center', fontsize=10, color='#AACDE8', transform=ax_header.transAxes)
ax_header.axis('off')

# KPI boxes
kpis = [
    (f'₹{total_revenue/1e6:.1f}M', 'Total Revenue', SAP_BLUE),
    (f'{total_orders}',            'Total Orders',   SAP_TEAL),
    (f'₹{avg_order_value/1e3:.0f}K','Avg Order Value', SAP_GREEN),
    (f'{completion_rate:.0f}%',    'Completion Rate', SAP_GOLD),
]
for i, (val, label, color) in enumerate(kpis):
    ax_kpi = fig.add_axes([0.02 + i * 0.245, 0.76, 0.22, 0.14])
    ax_kpi.set_facecolor(color)
    ax_kpi.text(0.5, 0.6, val,   ha='center', va='center', fontsize=22, fontweight='bold',
                color='white', transform=ax_kpi.transAxes)
    ax_kpi.text(0.5, 0.2, label, ha='center', va='center', fontsize=10,
                color='white', alpha=0.9, transform=ax_kpi.transAxes)
    ax_kpi.axis('off')

# Sub-charts
def load_img(path):
    from PIL import Image
    return np.array(Image.open(path))

positions = [
    [0.01, 0.39, 0.48, 0.35],
    [0.51, 0.39, 0.48, 0.35],
    [0.01, 0.01, 0.31, 0.35],
    [0.34, 0.01, 0.31, 0.35],
    [0.67, 0.01, 0.31, 0.35],
]
chart_files = [
    '/home/claude/sap_project/charts/chart1_monthly_revenue.png',
    '/home/claude/sap_project/charts/chart6_quarterly.png',
    '/home/claude/sap_project/charts/chart3_order_status.png',
    '/home/claude/sap_project/charts/chart4_regional_revenue.png',
    '/home/claude/sap_project/charts/chart2_top_customers.png',
]
for pos, cfile in zip(positions, chart_files):
    ax = fig.add_axes(pos)
    img = load_img(cfile)
    ax.imshow(img)
    ax.axis('off')

plt.savefig('/home/claude/sap_project/charts/dashboard_overview.png',
            bbox_inches='tight', dpi=150, facecolor='#F5F7FA')
plt.close()
print("✅ Dashboard saved")
print("\n🎉 All charts generated successfully!")
