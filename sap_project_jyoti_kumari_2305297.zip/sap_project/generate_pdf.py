"""
Capstone Project Documentation Generator
SAP O2C Analytics | Jyoti Kumari | Roll No: 2305297 | CSE
"""

from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm, mm
from reportlab.lib import colors
from reportlab.lib.enums import TA_JUSTIFY, TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Image, Table,
    TableStyle, PageBreak, HRFlowable
)
from reportlab.lib.utils import ImageReader
import os

# ── Colours ────────────────────────────────────────────
SAP_BLUE  = colors.HexColor('#003366')
SAP_TEAL  = colors.HexColor('#007DB8')
SAP_GOLD  = colors.HexColor('#F0AB00')
SAP_GREEN = colors.HexColor('#2D8653')
LIGHT_BG  = colors.HexColor('#EFF4FA')
WHITE     = colors.white

OUTPUT = '/home/claude/sap_project/Project_Documentation.pdf'
W, H   = A4

# ── Page template with header/footer ───────────────────
def make_header_footer(canvas, doc):
    canvas.saveState()
    # header bar
    canvas.setFillColor(SAP_BLUE)
    canvas.rect(0, H - 1.6*cm, W, 1.6*cm, fill=1, stroke=0)
    canvas.setFont('Helvetica-Bold', 10)
    canvas.setFillColor(WHITE)
    canvas.drawCentredString(W/2, H - 1.1*cm,
        'SAP Order-to-Cash Analytics | Capstone Project 2024')
    # footer
    canvas.setFillColor(SAP_BLUE)
    canvas.rect(0, 0, W, 1*cm, fill=1, stroke=0)
    canvas.setFont('Helvetica', 8)
    canvas.setFillColor(WHITE)
    canvas.drawString(1.5*cm, 0.35*cm,
        'Jyoti Kumari | Roll No: 2305297 | CSE | KIIT')
    canvas.setFont('Helvetica-Bold', 9)
    canvas.drawRightString(W - 1.5*cm, 0.35*cm, str(doc.page))
    canvas.restoreState()

# ── Doc setup ──────────────────────────────────────────
doc = SimpleDocTemplate(
    OUTPUT, pagesize=A4,
    leftMargin=2*cm, rightMargin=2*cm,
    topMargin=2.2*cm, bottomMargin=1.8*cm,
)
styles = getSampleStyleSheet()
story  = []

# ── Custom styles (Arial → Helvetica, closest built-in match) ──
def S(name, **kw):
    return ParagraphStyle(name, **kw)

H1 = S('H1', fontName='Helvetica-Bold', fontSize=15,
        textColor=SAP_BLUE, spaceAfter=8, spaceBefore=14,
        leading=20, alignment=TA_LEFT)
H2 = S('H2', fontName='Helvetica-Bold', fontSize=14,
        textColor=SAP_TEAL, spaceAfter=6, spaceBefore=10,
        leading=18, alignment=TA_LEFT)
BODY = S('BODY', fontName='Helvetica', fontSize=12,
         leading=18, alignment=TA_JUSTIFY, spaceAfter=6)
SMALL = S('SMALL', fontName='Helvetica', fontSize=10,
          leading=14, alignment=TA_JUSTIFY, spaceAfter=4)
CENTER = S('CENTER', fontName='Helvetica-Bold', fontSize=12,
           alignment=TA_CENTER, spaceAfter=4)

def hr():
    return HRFlowable(width='100%', thickness=1.2, color=SAP_TEAL,
                      spaceAfter=8, spaceBefore=4)
def sp(h=6):
    return Spacer(1, h)

def section_title(text):
    return [sp(8), Paragraph(text, H1), hr()]

def chart(path, w=16*cm, h=None, caption=None):
    items = []
    try:
        img = Image(path, width=w, height=h or w*0.48)
        img.hAlign = 'CENTER'
        items.append(img)
    except Exception as e:
        items.append(Paragraph(f'[Chart: {os.path.basename(path)}]', BODY))
    if caption:
        items.append(Paragraph(f'<i>{caption}</i>', S('cap',
            fontName='Helvetica-Oblique', fontSize=9,
            alignment=TA_CENTER, textColor=colors.grey, spaceAfter=8)))
    return items

# ══════════════════════════════════════════════════════
# PAGE 1 — TITLE PAGE
# ══════════════════════════════════════════════════════
title_style = S('title', fontName='Helvetica-Bold', fontSize=26,
                textColor=SAP_BLUE, alignment=TA_CENTER, leading=34, spaceAfter=6)
sub_style   = S('sub',   fontName='Helvetica',      fontSize=14,
                textColor=SAP_TEAL, alignment=TA_CENTER, spaceAfter=4)
meta_style  = S('meta',  fontName='Helvetica',      fontSize=12,
                textColor=colors.HexColor('#444444'), alignment=TA_CENTER, spaceAfter=5)

story += [
    sp(50),
    Paragraph('SAP Order-to-Cash (O2C)', title_style),
    Paragraph('Analytics Dashboard', title_style),
    sp(10),
    hr(),
    sp(6),
    Paragraph('A Data Analytics Capstone Project', sub_style),
    Paragraph('Simulating SAP Business Processes with Python', sub_style),
    sp(28),
]

# Info table on title page
info_data = [
    ['Student Name',  'Jyoti Kumari'],
    ['Roll Number',   '2305297'],
    ['Branch',        'Computer Science Engineering (CSE)'],
    ['Program',       'SAP — Data Analytics & Engineering'],
    ['Institution',   'KIIT'],
    ['Academic Year', '2024–25'],
    ['Submitted To',  'Capstone Project Faculty'],
]
info_table = Table(info_data, colWidths=[6*cm, 10*cm])
info_table.setStyle(TableStyle([
    ('BACKGROUND', (0,0), (0,-1), LIGHT_BG),
    ('TEXTCOLOR',  (0,0), (0,-1), SAP_BLUE),
    ('FONTNAME',   (0,0), (0,-1), 'Helvetica-Bold'),
    ('FONTNAME',   (1,0), (1,-1), 'Helvetica'),
    ('FONTSIZE',   (0,0), (-1,-1), 11),
    ('GRID',       (0,0), (-1,-1), 0.5, colors.HexColor('#C8D8E8')),
    ('ROWBACKGROUNDS', (0,0), (-1,-1), [WHITE, LIGHT_BG]),
    ('PADDING',    (0,0), (-1,-1), 8),
    ('VALIGN',     (0,0), (-1,-1), 'MIDDLE'),
]))
story += [info_table, PageBreak()]

# ══════════════════════════════════════════════════════
# PAGE 2 — PROBLEM STATEMENT & SOLUTION
# ══════════════════════════════════════════════════════
story += section_title('1. Problem Statement')
story += [
    Paragraph(
        'In modern enterprises, SAP ERP systems manage critical business processes such as '
        'Order-to-Cash (O2C), Procure-to-Pay (P2P), and financial reporting. However, raw '
        'transactional data from SAP modules is difficult to interpret without proper '
        'analytical tools. Business stakeholders need clear, visual insights to monitor '
        'sales performance, customer behaviour, regional trends, and order fulfilment rates.',
        BODY),
    Paragraph(
        'The challenge addressed in this project is: <b>How can SAP O2C transactional data '
        'be transformed into actionable business intelligence using Python-based analytics?</b> '
        'Without such analysis, decision-makers operate without visibility into revenue trends, '
        'top-performing customers, product demand, and regional disparities.',
        BODY),
    sp(4),
]

story += section_title('2. Solution & Features')
story += [
    Paragraph(
        'This project simulates a realistic SAP Order-to-Cash cycle using Python and builds '
        'a complete analytics dashboard that processes and visualises SAP-style transactional '
        'data. The solution covers the following capabilities:',
        BODY),
]

features = [
    ['#', 'Feature', 'Description'],
    ['1', 'SAP Data Simulation',     'Generates 200+ realistic O2C sales orders mimicking SAP SD module output'],
    ['2', 'KPI Dashboard',           'Displays key metrics: Total Revenue, Order Count, Avg Order Value, Completion Rate'],
    ['3', 'Monthly Revenue Trend',   'Line + bar chart showing month-wise revenue movement across FY 2024'],
    ['4', 'Customer Analytics',      'Identifies top 5 high-value customers by total revenue contribution'],
    ['5', 'Regional Analysis',       'Compares revenue performance across North, South, East, West regions'],
    ['6', 'Product Analytics',       'Breaks down revenue by product/service category'],
    ['7', 'Quarterly Performance',   'Dual-axis chart showing revenue vs. order volume per quarter'],
    ['8', 'Order Status Tracking',   'Pie chart showing Completed / Pending / In Progress distribution'],
    ['9', 'Inventory Management',    'Tracks product stock levels and flags items below reorder threshold'],
]
feat_table = Table(features, colWidths=[1*cm, 4.5*cm, 10.5*cm])
feat_table.setStyle(TableStyle([
    ('BACKGROUND',   (0,0), (-1,0),  SAP_BLUE),
    ('TEXTCOLOR',    (0,0), (-1,0),  WHITE),
    ('FONTNAME',     (0,0), (-1,0),  'Helvetica-Bold'),
    ('FONTNAME',     (0,1), (-1,-1), 'Helvetica'),
    ('FONTSIZE',     (0,0), (-1,-1), 9.5),
    ('ROWBACKGROUNDS',(0,1),(-1,-1), [WHITE, LIGHT_BG]),
    ('GRID',         (0,0), (-1,-1), 0.4, colors.HexColor('#C8D8E8')),
    ('PADDING',      (0,0), (-1,-1), 6),
    ('VALIGN',       (0,0), (-1,-1), 'MIDDLE'),
    ('ALIGN',        (0,0), (0,-1),  'CENTER'),
]))
story += [feat_table, PageBreak()]

# ══════════════════════════════════════════════════════
# PAGE 3 — TECH STACK & SCREENSHOTS
# ══════════════════════════════════════════════════════
story += section_title('3. Technology Stack')
tech = [
    ['Layer',           'Technology',        'Purpose'],
    ['Data Generation', 'Python + NumPy',     'Simulate SAP O2C transactional dataset (200 orders)'],
    ['Data Processing', 'Pandas',             'Data cleaning, aggregation, KPI computation'],
    ['Visualisation',   'Matplotlib + Seaborn','Chart generation — bar, line, pie, horizontal bar, dual-axis'],
    ['Documentation',   'ReportLab',          'PDF report generation with A4 formatting'],
    ['Version Control', 'Git + GitHub',        'Source code repository and collaboration'],
    ['IDE',             'VS Code / Jupyter',  'Development and testing environment'],
    ['Data Format',     'CSV',               'Structured data storage for SAP-style exports'],
]
tech_table = Table(tech, colWidths=[4*cm, 4*cm, 8*cm])
tech_table.setStyle(TableStyle([
    ('BACKGROUND',   (0,0), (-1,0),  SAP_TEAL),
    ('TEXTCOLOR',    (0,0), (-1,0),  WHITE),
    ('FONTNAME',     (0,0), (-1,0),  'Helvetica-Bold'),
    ('FONTNAME',     (0,1), (-1,-1), 'Helvetica'),
    ('FONTSIZE',     (0,0), (-1,-1), 10),
    ('ROWBACKGROUNDS',(0,1),(-1,-1), [WHITE, LIGHT_BG]),
    ('GRID',         (0,0), (-1,-1), 0.4, colors.HexColor('#C8D8E8')),
    ('PADDING',      (0,0), (-1,-1), 7),
    ('VALIGN',       (0,0), (-1,-1), 'MIDDLE'),
]))
story += [tech_table, sp(12)]

story += section_title('4. Screenshots — Working Sample')
story += [Paragraph('The following visualisations were generated by the project pipeline:', BODY)]
story += chart('/home/claude/sap_project/charts/chart1_monthly_revenue.png',
               caption='Fig 1: Monthly Revenue Trend — FY 2024')
story += chart('/home/claude/sap_project/charts/chart6_quarterly.png',
               caption='Fig 2: Quarterly Revenue vs Order Volume')
story += [PageBreak()]

story += chart('/home/claude/sap_project/charts/chart2_top_customers.png',
               caption='Fig 3: Top 5 Customers by Revenue')
story += chart('/home/claude/sap_project/charts/chart4_regional_revenue.png',
               caption='Fig 4: Revenue by Region')
story += [sp(8)]
story += chart('/home/claude/sap_project/charts/chart3_order_status.png',
               w=10*cm, h=8*cm,
               caption='Fig 5: Order Status Distribution')
story += [PageBreak()]

# ══════════════════════════════════════════════════════
# PAGE 5 — UNIQUE POINTS, INSIGHTS & FUTURE IMPROVEMENTS
# ══════════════════════════════════════════════════════
story += section_title('5. Key Business Insights')
story += [
    Paragraph('<b>Revenue Performance:</b> Total FY 2024 revenue reached ₹70.5M across 200 orders '
              'with an average order value of ₹352,643, demonstrating a healthy enterprise sales pipeline.', BODY),
    Paragraph('<b>Top Customer:</b> ITC Limited emerged as the highest revenue contributor, indicating '
              'a strong, concentrated B2B customer relationship that warrants key account management.', BODY),
    Paragraph('<b>Regional Gap:</b> Revenue distribution across regions revealed disparities that suggest '
              'untapped potential in lower-performing regions, warranting targeted sales strategies.', BODY),
    Paragraph('<b>Order Completion:</b> A 62.5% completion rate highlights significant room for improvement '
              'in the O2C fulfilment pipeline — pending and in-progress orders represent revenue leakage risk.', BODY),
    Paragraph('<b>Product Leaders:</b> The SAP S/4HANA Module and ERP Integration Kit are top revenue drivers, '
              'confirming the strategic value of core ERP products in the portfolio.', BODY),
    sp(4),
]

story += section_title('6. Unique Points of This Project')
unique = [
    '1. Fully self-contained — no live SAP connection required; data is generated programmatically to mirror real SAP SD exports.',
    '2. Covers the complete O2C cycle — from sales order creation through delivery, billing, and status tracking.',
    '3. Multi-dimensional analysis — customer, product, region, month, and quarter dimensions all explored.',
    '4. Professional dashboard layout combining KPI cards and 5 analytical charts in one unified view.',
    '5. SAP-authentic data schema — Order ID, Customer ID, Product ID, Discount, Delivery Date fields mirror actual SAP table structures (VBAK, VBAP).',
    '6. Reusable and scalable — the pipeline can be connected to a real SAP data export (CSV/Excel) with zero code changes.',
]
for u in unique:
    story.append(Paragraph(u, BODY))
story.append(sp(6))

story += section_title('7. Future Improvements')
future = [
    ['Enhancement', 'Description'],
    ['Live SAP Integration',     'Connect directly to SAP RFC/BAPI or SAP HANA DB for real-time data extraction'],
    ['Predictive Analytics',     'Use ML models (ARIMA, Linear Regression) to forecast next-quarter revenue'],
    ['Interactive Dashboard',    'Migrate charts to Power BI or Streamlit for interactive, web-based reporting'],
    ['Automated Alerts',         'Trigger email alerts when KPIs fall below defined thresholds (e.g., completion rate < 60%)'],
    ['Multi-Module Integration', 'Extend analytics to include SAP MM (P2P) and SAP FI (R2R) data pipelines'],
    ['Customer Segmentation',    'Apply RFM (Recency, Frequency, Monetary) analysis to classify customer tiers'],
]
fut_table = Table(future, colWidths=[5*cm, 11*cm])
fut_table.setStyle(TableStyle([
    ('BACKGROUND',   (0,0), (-1,0),  SAP_GREEN),
    ('TEXTCOLOR',    (0,0), (-1,0),  WHITE),
    ('FONTNAME',     (0,0), (-1,0),  'Helvetica-Bold'),
    ('FONTNAME',     (0,1), (-1,-1), 'Helvetica'),
    ('FONTSIZE',     (0,0), (-1,-1), 10),
    ('ROWBACKGROUNDS',(0,1),(-1,-1), [WHITE, LIGHT_BG]),
    ('GRID',         (0,0), (-1,-1), 0.4, colors.HexColor('#C8D8E8')),
    ('PADDING',      (0,0), (-1,-1), 7),
    ('VALIGN',       (0,0), (-1,-1), 'MIDDLE'),
]))
story += [fut_table, sp(12)]

story += [
    hr(),
    Paragraph(
        '<b>Declaration:</b> This project was independently developed by me. All code, analysis, '
        'and documentation is original work created as part of the Capstone Project requirement.',
        SMALL),
    Paragraph(
        'Jyoti Kumari &nbsp;|&nbsp; Roll No: 2305297 &nbsp;|&nbsp; Branch: CSE &nbsp;|&nbsp; '
        'Program: SAP — Data Analytics & Engineering',
        S('decl', fontName='Helvetica-Bold', fontSize=11, alignment=TA_CENTER,
          textColor=SAP_BLUE, spaceAfter=4, spaceBefore=8)),
]

# ── Build ──────────────────────────────────────────────
doc.build(story, onFirstPage=make_header_footer, onLaterPages=make_header_footer)
print(f"✅ PDF created: {OUTPUT}")
